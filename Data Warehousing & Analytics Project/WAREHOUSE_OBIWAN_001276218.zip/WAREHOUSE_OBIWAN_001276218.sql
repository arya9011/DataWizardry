--Creating Staging Area

CREATE TABLE WaterQuality_Main AS SELECT * FROM "_2000" UNION ALL SELECT * FROM "_2001" UNION ALL SELECT * FROM "_2002" 
UNION ALL SELECT * FROM "_2003" UNION ALL SELECT * FROM "_2004" UNION ALL SELECT * FROM "_2005" UNION ALL SELECT * FROM "_2006"
UNION ALL SELECT * FROM "_2007" UNION ALL SELECT * FROM "_2008" UNION ALL SELECT * FROM "_2009" UNION ALL SELECT * FROM "_2010"
UNION ALL SELECT * FROM "_2011" UNION ALL SELECT * FROM "_2012" UNION ALL SELECT * FROM "_2013" UNION ALL SELECT * FROM "_2014"
UNION ALL SELECT * FROM "_2015" UNION ALL SELECT * FROM "_2016";

--Checking for duplicates

SELECT "@id", COUNT(*)
FROM WaterQuality_Main
GROUP BY "@id"
HAVING COUNT(*) > 1;

COMMIT;

--Checking for missing values
SELECT 
    COUNT(CASE WHEN "MEASUREMENT_ID" IS NULL THEN 1 END) AS MEASUREMENT_ID_missing_count,
    COUNT(CASE WHEN "SAMPLING_POINT_NOTATION" IS NULL THEN 1 END) AS SAMPLING_POINT_NOTATION_missing_count,
    COUNT(CASE WHEN "SAMPLING_POINT_LABEL" IS NULL THEN 1 END) AS SAMPLING_POINT_LABEL_missing_count,
    COUNT(CASE WHEN "DETERMINAND_DEFINITION" IS NULL THEN 1 END) AS DETERMINAND_DEFINITION_missing_count,
    COUNT(CASE WHEN "DETERMINAND_NOTATION" IS NULL THEN 1 END) AS DETERMINAND_NOTATION_missing_count,
    COUNT(CASE WHEN "RESULT" IS NULL THEN 1 END) AS RESULT_missing_count,
    COUNT(CASE WHEN "DETERMINAND_UNIT" IS NULL THEN 1 END) AS DETERMINAND_UNIT_missing_count,
    COUNT(CASE WHEN "SAMPLE_MATERIAL_TYPE" IS NULL THEN 1 END) AS SAMPLE_MATERIAL_TYPE_missing_count,
    COUNT(CASE WHEN "SAMPLE_PURPOSE_LABEL" IS NULL THEN 1 END) AS SAMPLE_PURPOSE_LABEL_missing_count,
    COUNT(CASE WHEN "SAMPLING_POINT_EASTING" IS NULL THEN 1 END) AS SAMPLING_POINT_EASTING_missing_count,
    COUNT(CASE WHEN "SAMPLING_POINT_NORTHING" IS NULL THEN 1 END) AS SAMPLING_POINT_NORTHING_missing_count,
    COUNT(CASE WHEN "SAMPLEDATE" IS NULL THEN 1 END) AS SAMPLE_DATE_missing_count,
    COUNT(CASE WHEN "SAMPLETIME" IS NULL THEN 1 END) AS SAMPLE_TIME_missing_count
FROM WaterQuality_Main;
COMMIT;

--removing URL part from @id

UPDATE WaterQuality_Main
SET "@id" = SUBSTR("@id", LENGTH('http://environment.data.gov.uk/water-quality/data/measurement/') + 1)
WHERE "@id" LIKE 'http://environment.data.gov.uk/water-quality/data/measurement/%';

COMMIT;

--Dropping Columns
ALTER TABLE WaterQuality_Main DROP ("ID1", "ID", "samplesamplingPoint","determinandlabel", "codedResultInterpretationinterpretation", "resultQualifiernotation" );
ALTER TABLE WaterQuality_Main DROP COLUMN "samplesampleDateTime";
ALTER TABLE WaterQuality_Main DROP COLUMN "sampleisComplianceSample";

commit;

--Seperating samplesampleDateTime to sampleDate and sampleTime
SELECT value
FROM nls_session_parameters
WHERE parameter = 'NLS_DATE_FORMAT';

ALTER SESSION SET NLS_DATE_FORMAT = 'YYYY-MM-DD';


ALTER TABLE WaterQuality_Main
ADD (sampleDate DATE, sampleTime VARCHAR2(8));

UPDATE WaterQuality_Main
SET sampleDate = TO_DATE("samplesampleDateTime", 'YYYY-MM-DD"T"HH24:MI:SS'),
    sampleTime  = TO_CHAR(TO_DATE("samplesampleDateTime", 'YYYY-MM-DD"T"HH24:MI:SS'), 'HH24:MI:SS');
    


--Rename Columns

ALTER TABLE WaterQuality_Main RENAME COLUMN "@id" TO MEASUREMENT_ID;
ALTER TABLE WaterQuality_Main RENAME COLUMN "samplesamplingPointnotation" TO SAMPLING_POINT_NOTATION;
ALTER TABLE WaterQuality_Main RENAME COLUMN "samplesamplingPointlabel" TO SAMPLING_POINT_LABEL;
ALTER TABLE WaterQuality_Main RENAME COLUMN "determinanddefinition" TO DETERMINAND_DEFINITION;
ALTER TABLE WaterQuality_Main RENAME COLUMN "determinandnotation" TO DETERMINAND_NOTATION;
ALTER TABLE WaterQuality_Main RENAME COLUMN "result" TO RESULT;
ALTER TABLE WaterQuality_Main RENAME COLUMN "determinandunitlabel" TO DETERMINAND_UNIT;
ALTER TABLE WaterQuality_Main RENAME COLUMN "samplesampledMaterialTypelabel" TO SAMPLE_MATERIAL_TYPE;
ALTER TABLE WaterQuality_Main RENAME COLUMN "samplepurposelabel" TO SAMPLE_PURPOSE_LABEL;
ALTER TABLE WaterQuality_Main RENAME COLUMN "samplesamplingPointeasting" TO SAMPLING_POINT_EASTING;
ALTER TABLE WaterQuality_Main RENAME COLUMN "samplesamplingPointnorthing" TO SAMPLING_POINT_NORTHING;


commit;



--Removing the semicolons from DETERMINAND_DEFINITION

UPDATE WaterQuality_Main
SET DETERMINAND_DEFINITION = REPLACE(DETERMINAND_DEFINITION, ':', ' ');



--Creating Warehouse Tables

CREATE TABLE DW_SAMPLING (
      SAMPLE_SAMPLING_POINT_NOTATION VARCHAR2(50) PRIMARY KEY,
      SAMPLE_SAMPLING_POINT_LABEL VARCHAR2(50),
      SAMPLE_SAMPLING_POINT_EASTING NUMBER,
      SAMPLE_SAMPLING_POINT_NORTHING NUMBER
      );

CREATE TABLE DW_DETERMINAND(
     DETERMINAND_NOTATION_ NUMBER PRIMARY KEY,
     DETERMINAND_DEFINITION_ VARCHAR2(100),
     DETERMINANTD_UNIT_ VARCHAR2(20)
     );

CREATE TABLE DW_PURPOSE(
     
     SAMPLE_PURPOSE_ID_ INT PRIMARY KEY,
     SAMPLE_PURPOSE_LABEL_ VARCHAR2(100),
     SAMPLE_MATERIAL_TYPE_ VARCHAR2(100)
     );
     
CREATE TABLE DW_TIME(

     TIME_ID INT PRIMARY KEY,
     SAMPLE_DATE DATE, 
     SAMPLE_TIME VARCHAR2(10),
     SAMPLE_YEAR NUMBER,
     SAMPLE_MONTH NUMBER,
     SAMPLE_WEEK NUMBER,
     SAMPLE_DAY NUMBER
     );

--Fact Table Creation

CREATE TABLE Fact_WaterQuality (
    MeasurementID INT PRIMARY KEY,
    SAMPLE_SAMPLING_POINT_NOTATION VARCHAR2(50),
    DETERMINAND_NOTATION_ NUMBER,
    SAMPLE_PURPOSE_ID_ INT,
    TIME_ID INT,
    SAMPLE_RESULT FLOAT,
    CONSTRAINT fk_sampling_point FOREIGN KEY (SAMPLE_SAMPLING_POINT_NOTATION) REFERENCES DW_SAMPLING(SAMPLE_SAMPLING_POINT_NOTATION),
    CONSTRAINT fk_time FOREIGN KEY (TIME_ID) REFERENCES DW_TIME(TIME_ID),
    CONSTRAINT fk_purpose FOREIGN KEY (SAMPLE_PURPOSE_ID_) REFERENCES DW_PURPOSE(SAMPLE_PURPOSE_ID_),
    CONSTRAINT fk_determinand FOREIGN KEY (DETERMINAND_NOTATION_) REFERENCES DW_DETERMINAND(DETERMINAND_NOTATION_)
    );
    


 --Using cursor upload for DW_SAMPLING
DECLARE
    CURSOR c_data IS
        SELECT DISTINCT
            SAMPLING_POINT_NOTATION,
            SAMPLING_POINT_LABEL,
            SAMPLING_POINT_EASTING,
            SAMPLING_POINT_NORTHING
        FROM WATERQUALITY_MAIN;

    sampling_notation VARCHAR2(50);
    sampling_label VARCHAR2(50);
    sampling_easting NUMBER;
    sampling_northing NUMBER;
    
BEGIN
    FOR data IN c_data LOOP
        sampling_notation := data.SAMPLING_POINT_NOTATION;
        sampling_label := data.SAMPLING_POINT_LABEL;
        sampling_easting := data.SAMPLING_POINT_EASTING;
        sampling_northing := data.SAMPLING_POINT_NORTHING;
             
     INSERT INTO DW_SAMPLING (
                SAMPLE_SAMPLING_POINT_NOTATION,
                SAMPLE_SAMPLING_POINT_LABEL,
                SAMPLE_SAMPLING_POINT_EASTING,
                SAMPLE_SAMPLING_POINT_NORTHING    
            ) VALUES (
                sampling_notation,
                sampling_label,
                sampling_easting,
                sampling_northing
                
            );
        
    END LOOP;
END;
/

--Using Cursor for Determinant

DECLARE
    CURSOR c_data IS
        SELECT DISTINCT
            DETERMINAND_NOTATION,
            DETERMINAND_DEFINITION,
            DETERMINAND_UNIT
        FROM WATERQUALITY_MAIN;

    deter_notation NUMBER;
    deter_def VARCHAR2(100);
    deter_unit VARCHAR2(20);
    
BEGIN
    FOR data IN c_data LOOP
        deter_notation := data.DETERMINAND_NOTATION;
        deter_def := data.DETERMINAND_DEFINITION;
        deter_unit := data.DETERMINAND_UNIT;
             
    INSERT INTO DW_DETERMINAND (
                DETERMINAND_NOTATION_,
                DETERMINAND_DEFINITION_,
                DETERMINANTD_UNIT_
                
            ) VALUES (
                deter_notation,
                deter_def,
                deter_unit
                
            );
        
    END LOOP;
END;
/

--Using Cursor for DW_PURPOSE

CREATE SEQUENCE SEQ_PURPOSE_ID START WITH 1 INCREMENT BY 1;
DECLARE
    CURSOR c_data IS
        SELECT DISTINCT
            SAMPLE_PURPOSE_LABEL,
            SAMPLE_MATERIAL_TYPE
        FROM WATERQUALITY_MAIN;

    purpose_id INT;
    purpose_label VARCHAR2(100);
    material_type VARCHAR2(100);
    
BEGIN
    FOR data IN c_data LOOP
        SELECT SEQ_PURPOSE_ID.NEXTVAL INTO purpose_id FROM DUAL;
        purpose_label := data.SAMPLE_PURPOSE_LABEL;
        material_type := data.SAMPLE_MATERIAL_TYPE;
             
    INSERT INTO DW_PURPOSE (
                SAMPLE_PURPOSE_ID_,
                SAMPLE_PURPOSE_LABEL_,
                SAMPLE_MATERIAL_TYPE_
                
            ) VALUES (
                purpose_id,
                purpose_label,
                material_type
                
            );
        
    END LOOP;
END;
/

--Using Cursor for DW_TIME

CREATE SEQUENCE SEQ_TIME_ID START WITH 1 INCREMENT BY 1;

DECLARE
    CURSOR c_data IS
        SELECT DISTINCT
            SAMPLEDATE,
            SAMPLETIME
        FROM WATERQUALITY_MAIN;

    id_time INT;
    sam_date DATE;
    sam_time VARCHAR2(10);
    sam_year NUMBER;
    sam_month NUMBER;
    sam_week NUMBER;
    sam_day NUMBER;
BEGIN
    FOR data IN c_data LOOP
        SELECT SEQ_TIME_ID.NEXTVAL INTO id_time FROM DUAL;
        sam_date := data.SAMPLEDATE;
        sam_time := data.SAMPLETIME;
        sam_year := EXTRACT(YEAR FROM sam_date);
        sam_month := EXTRACT(MONTH FROM sam_date);
        sam_day := EXTRACT(DAY FROM sam_date);
        sam_week := TO_NUMBER(TO_CHAR(sam_date, 'IW'));
        
        INSERT INTO DW_TIME (
            TIME_ID,
            SAMPLE_DATE,
            SAMPLE_TIME,
            SAMPLE_YEAR,
            SAMPLE_MONTH,
            SAMPLE_WEEK,
            SAMPLE_DAY
        ) VALUES (
            id_time,
            sam_date,
            sam_time,
            sam_year,
            sam_month,
            sam_week,
            sam_day            
        );
        
    END LOOP;
END;
/


-- insert data into fact table

INSERT INTO FACT_WATERQUALITY(MEASUREMENTID, SAMPLE_SAMPLING_POINT_NOTATION, DETERMINAND_NOTATION_, TIME_ID, SAMPLE_PURPOSE_ID_, SAMPLE_RESULT)

SELECT 

    m.MEASUREMENT_ID,

    s.SAMPLE_SAMPLING_POINT_NOTATION,

    d.DETERMINAND_NOTATION_,

    t.TIME_ID,

    p.SAMPLE_PURPOSE_ID_,

    m.RESULT

FROM WATERQUALITY_MAIN m

LEFT JOIN DW_SAMPLING s ON m.SAMPLING_POINT_NOTATION = s.SAMPLE_SAMPLING_POINT_NOTATION

LEFT JOIN DW_DETERMINAND d ON m.DETERMINAND_NOTATION = d.DETERMINAND_NOTATION_

LEFT JOIN DW_TIME t ON m.SAMPLEDATE = t.SAMPLE_DATE AND m.SAMPLETIME = t.SAMPLE_TIME

LEFT JOIN DW_PURPOSE p ON m.SAMPLE_PURPOSE_LABEL = p.SAMPLE_PURPOSE_LABEL_ AND m.SAMPLE_MATERIAL_TYPE = p.SAMPLE_MATERIAL_TYPE_;


